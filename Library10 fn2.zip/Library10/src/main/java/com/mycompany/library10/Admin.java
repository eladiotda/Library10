package com.mycompany.library10;

public class Admin extends User {
    public Admin(String id, String documentNumber, String documentType, String name, String password) {
        super(id, documentNumber, documentType, name, password);
    }
}
