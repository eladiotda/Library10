package com.mycompany.library10;

public class Teacher extends User {
    public Teacher(String id, String documentNumber, String documentType, String name, String password) {
        super(id, documentNumber, documentType, name, password);
    }
}
