package com.mycompany.library10;

public class Student extends User {
    public Student(String id, String documentNumber, String documentType, String name, String password) {
        super(id, documentNumber, documentType, name, password);
    }
}
